/*##############################################################################
# Copyright 2021 IBM Corp. All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
##############################################################################*/
package tat.bank.ui.webapp.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tat.bank.ui.webapp.domains.Account;
import tat.bank.ui.webapp.exceptions.AccountNotFoundException;
import tat.bank.ui.webapp.services.AccountService;

@Controller
@RequestMapping("accountDetails")
public class AccountQueryController {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	private final AccountService accountService;
	public AccountQueryController(AccountService accountService) {
		super();
		this.accountService = accountService;
	
	}

	@RequestMapping
	public String accountDetails(@RequestParam("accountId") String accountId, Model model) {

		logger.info(" <----------- accountDetails ------> " + accountId);

		if (accountId != null) {
						
									
					try {
						
						Account	account = accountService.findAccountById(accountId);
						model.addAttribute("accountId", account.getAccountId());
						model.addAttribute("account", account);
						logger.info(" <----------- account ------> " + account);
						
					} catch (AccountNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						
						return "showException";
					}
					

			
			} else {

				return "showException";
			}
		
		return "accountDetails";
	}

}
